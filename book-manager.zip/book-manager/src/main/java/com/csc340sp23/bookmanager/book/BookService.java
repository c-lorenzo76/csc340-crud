/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.csc340sp23.bookmanager.book;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author cristian
 */
@Service
public class BookService {
    
    @Autowired
    private BookRepository repo;
    
    public List<Book> getAllBooks(){
        return repo.findAll();
    }
     public Book getBook(long bookID){
        return repo.getReferenceById(bookID);
    }
    
    public void deleteBook(long bookID){
        repo.deleteById(bookID);
    }
    
    void saveBook(Book book){
        repo.save(book);
    }
}
